import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactmanager',
  templateUrl: './contactmanager.component.html',
  styleUrls: ['./contactmanager.component.scss']
})
export class ContactmanagerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
