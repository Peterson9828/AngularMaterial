export class Notes {
  id: number;
  title: string;
  date: Date;
}
